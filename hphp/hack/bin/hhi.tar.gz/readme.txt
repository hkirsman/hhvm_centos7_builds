Hack for HipHop interface files.

These files provide type information for some of PHP's predefined classes,
interfaces and functions.
